function signUpSubmit() {
    document.getElementById("signupsheet").submit(); 
} 
function validateForm() {
    let val=document.forms["signup"]["email"].value; 
    if (val=="") {
        alert("Email field must be filled out.") 
        return false; 
        }
    }
 function thankYouMssg() {
    document.getElementById("button").addEventListener("click",alert("Thank you for signing up!"));
 } 